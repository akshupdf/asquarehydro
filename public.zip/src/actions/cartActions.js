import { ADD_TO_CART , REMOVE_FROM_CART } from "./actionTypes";


export const addToCart = (product) => ({

    type: ADD_TO_CART,
    payload : product
})

export const removeCartItem = (productId) => ({
    type: REMOVE_FROM_CART,
    payload : productId
})